#ifndef _MAIN_H__
#define _MAIN_H__

struct config_type
{
  char stassid[32];
  char stapsw[32];
  char stapsn[64];
  char id[32];
  char key[32];
  char pwd[32];
  char logpwd[32];
  size_t pl;
  uint8_t magic;
};

void startTCPClient();
void doTCPClientTick();
void startUDPServer(int);
void doUdpServerTick();
void sendTCP(char *);
void sendUDP(char *);
void initParseData();
void parseTCPPackage(char*);
void parseUDPPackage(char*);
void parseUartPackage(char*);

void initHttpServer();
void doHttpServerTick();
void delayRestart(float);
void initMqttClient();
void linkMqttServer();
//void initGpio();
//void sendStateToMqtt();
void setmDns();

//常量
#define VER             "LightingM5_V1.0"
#define DEFAULT_APSSID  "LightingM5"
#define DEFAULT_STASSID ""
#define DEFAULT_STAPSW  ""
#define PINLED          2  //16是小板，大班是2
#define PINKEY          38
#define HOST_NAME       "Fii_Iot"
#define DEFAULT_PL      10 //默認頻率


//MQTT Server 配置
#define DEFAULT_ID    ""                      //MQTT Server IP
#define DEFAULT_KEY    ""                              //MQTT User Name
#define DEFAULT_PWD    ""                          //MQTT User Name

const char apssid[]=DEFAULT_APSSID;

unsigned long lastWiFiCheckTick = 0;
bool ledState = 0;
bool debug = 1;
bool isOne = 1;//第一次启动需要设置设备地址
bool isWiFiErr = 1;

#include <M5Stack.h>
config_type config;
WiFiClient wclient;
PubSubClient client(wclient);
//PubSubClient mqttClient(wclient);
bool isConnMqttServer = 1;

String s = "";          //json頭 sn + dn
String mySn = ""; //设备SN设备信息
String ipMac = "";
String recoveryPassword = "fii"; //恢复出厂设置密码
long dispRssi = 0;

int yellow = 35;
int green = 36;  
int red = 34;

#define PINKEYA  39
#define PINKEYB  38
#define PINKEYC  37

#define PRODUCT_KEY      "" //替换自己的PRODUCT_KEY
#define DEVICE_NAME      "" //替换自己的DEVICE_NAME
#define DEVICE_SECRET    ""//替换自己的DEVICE_SECRET

#define DEV_VERSION       "S-TH-WIFI-v1.0-20200407"        //固件版本信息

char * P_KEY = config.id; //现有PRODUCT_KEY
char * D_NAME = config.key; //现有DEVICE_NAME
char * D_SECRET = config.pwd; //现有DEVICE_SECRET

#define ALINK_BODY_FORMAT         "{\"id\":\"123\",\"version\":\"1.0\",\"method\":\"%s\",\"params\":%s}"
//#define ALINK_TOPIC_PROP_POST     "/sys/" PRODUCT_KEY "/" DEVICE_NAME "/thing/event/property/post"
//#define ALINK_TOPIC_PROP_POSTRSP  "/sys/" PRODUCT_KEY "/" DEVICE_NAME "/thing/event/property/post_reply"
//#define ALINK_TOPIC_PROP_SET      "/sys/" PRODUCT_KEY "/" DEVICE_NAME "/thing/service/property/set"
#define ALINK_METHOD_PROP_POST    "thing.event.property.post"
//#define ALINK_TOPIC_DEV_INFO      "/ota/device/inform/" PRODUCT_KEY "/" DEVICE_NAME ""    
#define ALINK_VERSION_FROMA      "{\"id\": 123,\"params\": {\"version\": \"%s\"}}"
unsigned long lastMs = 0;

static String mqttBroker;
static String mqttClientID;
static String mqttUserName;
static String mqttPassword;

#include <SHA256.h>

#define MQTT_PORT 1883
#define SHA256HMAC_SIZE 32

#endif
